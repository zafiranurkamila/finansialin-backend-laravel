<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('transactions', function (Blueprint $table): void {
            if (Schema::hasColumn('transactions', 'receiptImagePath')) {
                $table->dropColumn('receiptImagePath');
            }
        });
    }

    public function down(): void
    {
        Schema::table('transactions', function (Blueprint $table): void {
            if (!Schema::hasColumn('transactions', 'receiptImagePath')) {
                $table->string('receiptImagePath')->nullable()->after('date');
            }
        });
    }
};
