<?php

namespace App\Http\Controllers;

use App\Models\Budget;
use App\Models\Category;
use App\Models\Resource;
use App\Models\Transaction;
use App\Models\User;
use App\Models\UserNotification;
use App\Services\ResourceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;

class WebhookIntegrationsController extends Controller
{

    public function receiptOcr(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'receiptImage' => ['required', 'file', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => $validator->errors()->first()], 422);
        }

        $file = $request->file('receiptImage');
        if ($file === null) {
            return response()->json(['message' => 'receiptImage is required'], 422);
        }

        $serviceUrl = rtrim((string) config('services.ocr.service_url', 'http://127.0.0.1:8002'), '/');

        try {
            $queuedResult = $this->runQueuedOcr($file, $serviceUrl);

            if ($queuedResult['ok']) {
                return response()->json($queuedResult['body'], 200);
            }

            return response()->json([
                'message' => $queuedResult['message'],
                'details' => $queuedResult['body'],
            ], $queuedResult['status']);
        } catch (\Throwable $e) {
            return response()->json([
                'message' => 'Failed to connect to AI service',
                'error' => $e->getMessage(),
                'service_url' => $serviceUrl,
            ], 500);
        }
    }

    private function runQueuedOcr(UploadedFile $file, string $serviceUrl): array
    {
        $submitResponse = Http::timeout(30)->attach(
            'receiptImage',
            file_get_contents($file->getRealPath()),
            $file->getClientOriginalName()
        )->post($serviceUrl . '/ocr/jobs');

        if (!$submitResponse->successful()) {
            return [
                'ok' => false,
                'status' => $submitResponse->status(),
                'message' => 'AI Service Error',
                'body' => $submitResponse->json(),
            ];
        }

        $submitPayload = $submitResponse->json();
        $jobId = is_array($submitPayload) ? ($submitPayload['job_id'] ?? null) : null;

        if (!is_string($jobId) || $jobId === '') {
            return [
                'ok' => false,
                'status' => 502,
                'message' => 'AI Service returned an invalid OCR job response',
                'body' => $submitPayload,
            ];
        }

        $deadline = microtime(true) + 110;
        $lastPayload = $submitPayload;

        do {
            usleep(750000);

            $pollResponse = Http::timeout(10)->get($serviceUrl . '/ocr/jobs/' . rawurlencode($jobId));
            $lastPayload = $pollResponse->json();

            if (!$pollResponse->successful()) {
                return [
                    'ok' => false,
                    'status' => $pollResponse->status(),
                    'message' => 'AI Service Error',
                    'body' => $lastPayload,
                ];
            }

            if (!is_array($lastPayload)) {
                continue;
            }

            $status = (string) ($lastPayload['status'] ?? 'unknown');

            if ($status === 'done') {
                $result = $lastPayload['result'] ?? [];
                return [
                    'ok' => true,
                    'status' => 200,
                    'message' => 'OCR completed',
                    'body' => $this->normalizeQueuedOcrResult(is_array($result) ? $result : []),
                ];
            }

            if ($status === 'failed') {
                return [
                    'ok' => false,
                    'status' => 502,
                    'message' => 'AI Service OCR job failed',
                    'body' => $lastPayload,
                ];
            }
        } while (microtime(true) < $deadline);

        return [
            'ok' => false,
            'status' => 504,
            'message' => 'AI Service OCR job timed out',
            'body' => $lastPayload,
        ];
    }

    private function normalizeQueuedOcrResult(array $result): array
    {
        $data = $result['data'] ?? $result;
        $data = is_array($data) ? $data : [];

        $response = [
            'status' => $result['status'] ?? 'success',
            'data' => [
                'merchant_name' => $data['merchant_name'] ?? null,
                'total_amount' => $this->normalizeReceiptAmount($data['total_amount'] ?? null),
                'date' => $data['date'] ?? null,
                'suggested_category' => $data['suggested_category'] ?? 10,
            ],
            'engine' => 'donut',
        ];

        if (array_key_exists('debug_raw_ai', $result)) {
            $response['debug_raw_ai'] = $result['debug_raw_ai'];
        }

        return $response;
    }

    private function normalizeReceiptAmount(mixed $amount): float
    {
        if (is_string($amount)) {
            $amountPart = preg_replace('/[^\d\.,]/', '', $amount) ?? '';

            if ($amountPart === '') {
                return 0.0;
            }

            $lastDot = strrpos($amountPart, '.');
            $lastComma = strrpos($amountPart, ',');
            $lastSeparator = max($lastDot === false ? -1 : $lastDot, $lastComma === false ? -1 : $lastComma);

            if ($lastSeparator >= 0) {
                $before = substr($amountPart, 0, $lastSeparator);
                $after = substr($amountPart, $lastSeparator + 1);
                $beforeDigits = preg_replace('/\D/', '', $before) ?? '';
                $hasOtherSeparator = str_contains($before, '.') || str_contains($before, ',');

                if (strlen($after) === 2 && ($hasOtherSeparator || strlen($beforeDigits) > 3)) {
                    $amountPart = $before;
                }
            }

            $clean = preg_replace('/\D/', '', $amountPart) ?? '';
            return $clean === '' ? 0.0 : (float) $clean;
        }

        if (is_int($amount) || is_float($amount)) {
            $value = (float) $amount;

            if ($value > 0 && $value < 1000) {
                $raw = rtrim(rtrim(number_format($value, 6, '.', ''), '0'), '.');
                $digits = preg_replace('/\D/', '', $raw) ?? '';

                if (strlen($digits) <= 2) {
                    return (float) ((int) $digits * 1000);
                }

                if (strlen($digits) === 3) {
                    return (float) ((int) $digits * 100);
                }
            }

            return $value;
        }

        return 0.0;
    }

public function ingestQrisEmail(Request $request): JsonResponse
    {
        $expectedSecret = (string) env('N8N_QRIS_WEBHOOK_SECRET', '');
        $providedSecret = (string) $request->header('X-Webhook-Secret', '');

        if ($expectedSecret === '' || !hash_equals($expectedSecret, $providedSecret)) {
            return response()->json(['message' => 'Unauthorized webhook request'], 401);
        }

        $validator = Validator::make($request->all(), [
            'email' => ['required', 'email'],
            'amount' => ['required'],
            'paidAt' => ['nullable', 'date'],
            'description' => ['nullable', 'string', 'max:500'],
            'source' => ['nullable', 'string', 'max:120'],
            'categoryName' => ['nullable', 'string', 'max:100'],
            'merchant' => ['nullable', 'string', 'max:120'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
            ], 422);
        }

        $user = User::query()
            ->where('email', strtolower((string) $request->input('email')))
            ->first();

        if (!$user) {
            return response()->json([
                'message' => 'User not found for provided email',
            ], 404);
        }

        $amount = $this->normalizeAmount((string) $request->input('amount'));
        if ($amount <= 0) {
            return response()->json([
                'message' => 'Invalid amount',
            ], 422);
        }

        $category = $this->resolveExpenseCategory(
            (int) $user->idUser,
            $request->input('categoryName')
        );

        $description = trim((string) ($request->input('description') ?? ''));
        $merchant = trim((string) ($request->input('merchant') ?? ''));
        $sourceName = trim((string) ($request->input('source') ?? ''));

        if ($description === '' && $merchant !== '') {
            $description = 'QRIS payment to ' . $merchant;
        }

        $idResource = $this->resolveResourceId((int) $user->idUser, $sourceName);

        $transaction = Transaction::query()->create([
            'idUser' => $user->idUser,
            'idCategory' => $category?->idCategory,
            'idResource' => $idResource,
            'type' => 'expense',
            'amount' => number_format($amount, 2, '.', ''),
            'description' => $description !== '' ? $description : 'QRIS payment from email automation',
            'date' => $request->filled('paidAt') ? $request->input('paidAt') : now(),
        ]);

        if ($idResource) {
            ResourceService::withdrawFromResource($idResource, $amount);
        }

        $this->notifyTransaction((int) $user->idUser, $transaction, true);
        $this->checkBudgetWarning($user, $transaction);

        return response()->json([
            'message' => 'QRIS email transaction ingested',
            'data' => $transaction->fresh(['category']),
        ], 201);
    }

    private function resolveExpenseCategory(int $userId, mixed $categoryName): ?Category
    {
        $name = trim((string) ($categoryName ?? ''));

        if ($name !== '') {
            $match = Category::query()
                ->whereRaw('LOWER(name) = ?', [strtolower($name)])
                ->where('type', 'expense')
                ->where(function ($query) use ($userId) {
                    $query->whereNull('idUser')->orWhere('idUser', $userId);
                })
                ->orderByRaw('CASE WHEN "idUser" IS NULL THEN 1 ELSE 0 END')
                ->first();

            if ($match) {
                return $match;
            }
        }

        return Category::query()
            ->where('type', 'expense')
            ->where(function ($query) use ($userId) {
                $query->whereNull('idUser')->orWhere('idUser', $userId);
            })
            ->orderByRaw('CASE WHEN "idUser" IS NULL THEN 1 ELSE 0 END')
            ->orderBy('name')
            ->first();
    }

    private function normalizeAmount(string $rawAmount): float
    {
        $value = trim($rawAmount);
        $value = preg_replace('/[^0-9,\.]/', '', $value) ?? '';

        if ($value === '') {
            return 0.0;
        }

        // Handle thousand separators and decimal comma from Indonesian formatting.
        if (str_contains($value, ',') && str_contains($value, '.')) {
            $value = str_replace('.', '', $value);
            $value = str_replace(',', '.', $value);
        } elseif (str_contains($value, ',')) {
            $value = str_replace(',', '.', $value);
        }

        return (float) $value;
    }

    private function resolveResourceId(int $userId, string $sourceName): ?int
    {
        $name = trim($sourceName);
        if ($name === '') {
            return null;
        }

        $resource = Resource::query()
            ->where('idUser', $userId)
            ->whereRaw('LOWER(source) = ?', [strtolower($name)])
            ->first();

        if ($resource) {
            return $resource->idResource;
        }

        return null;
    }

    private function notifyTransaction(int $userId, Transaction $tx, bool $isCreate): void
    {
        $label = $tx->type === 'income' ? 'Pemasukan' : 'Pengeluaran';
        $action = $isCreate ? 'ditambahkan' : 'dihapus';
        $formatted = number_format((float) $tx->amount, 0, ',', '.');

        UserNotification::create([
            'idUser' => $userId,
            'type' => $isCreate ? 'TRANSACTION_CREATED' : 'TRANSACTION_DELETED',
            'read' => false,
            'message' => $label . ' sebesar Rp' . $formatted . ' telah ' . $action . '.',
        ]);
    }

    private function checkBudgetWarning(User $user, Transaction $tx): void
    {
        if ($tx->type !== 'expense' || !$tx->idCategory) {
            return;
        }

        $budgets = Budget::query()
            ->where('idUser', $user->idUser)
            ->where('idCategory', $tx->idCategory)
            ->where('periodStart', '<=', $tx->date)
            ->where('periodEnd', '>=', $tx->date->startOfDay())
            ->get();

        foreach ($budgets as $budget) {
            $spent = (float) Transaction::query()
                ->where('idUser', $user->idUser)
                ->where('idCategory', $tx->idCategory)
                ->where('type', 'expense')
                ->whereBetween('date', [$budget->periodStart->startOfDay(), $budget->periodEnd->endOfDay()])
                ->sum('amount');

            $limit = (float) $budget->amount;
            if ($limit <= 0) {
                continue;
            }

            $percent = ($spent / $limit) * 100;
            $categoryName = $tx->category?->name ?? 'Unknown';

            if ($percent >= 100) {
                UserNotification::create([
                    'idUser' => $user->idUser,
                    'type' => 'BUDGET_EXCEEDED',
                    'read' => false,
                    'message' => 'Budget ' . $categoryName . ' telah melebihi batas.',
                ]);
            } elseif ($percent >= 80) {
                UserNotification::create([
                    'idUser' => $user->idUser,
                    'type' => 'BUDGET_WARNING',
                    'read' => false,
                    'message' => 'Budget ' . $categoryName . ' sudah mencapai ' . round($percent) . '%.',
                ]);
            }
        }
    }
}
